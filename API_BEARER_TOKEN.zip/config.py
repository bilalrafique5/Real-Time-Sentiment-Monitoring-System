# Twitter API Credentials
API_BEARER_TOKEN="AAAAAAAAAAAAAAAAAAAAADtq6QEAAAAABxNyJuP5rteI9E00KoqqSPax2CU%3D7fAkZRL4mbDkrVQmbgnAueSR9fL4f78CWHFofTIRsvcRbgMAjL"


# Database Path
DB_PATH="sentiment.db"


# Cache policy: when checking DB for cached tweets, how many hours back to consider fresh
CACHE_HOURS = 10


MAX_TWEETS_PER_CALL = 15  # Twitter API max is 100

SERVICE_ACCOUNT_PATH = "serviceAccountKey.json"

